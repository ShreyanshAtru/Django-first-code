from django.shortcuts import render
from django.http import HttpResponse

# Create your views here.

def index(request):
    return render(request , 'app.html',{'name' : 'Shreyansh'})

def contact(request):
    return HttpResponse("<h1>this is home contact</h1> ")

def about(request):
    return render( request ,'base.html')